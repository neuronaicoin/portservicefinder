// ============================================================
// PORTS & SERVICES — the one list the whole site uses: countries, their ports (the port
// pickers, port pages and the "1,200+ ports" coverage), flags and service categories.
// ============================================================

export const FLAG: Record<string, string> = {
  'Albania':'🇦🇱','Algeria':'🇩🇿','Angola':'🇦🇴','Antigua and Barbuda':'🇦🇬','Argentina':'🇦🇷','Aruba':'🇦🇼','Australia':'🇦🇺','Bahamas':'🇧🇸','Bahrain':'🇧🇭','Bangladesh':'🇧🇩','Barbados':'🇧🇧','Belgium':'🇧🇪','Belize':'🇧🇿','Benin':'🇧🇯','Bermuda':'🇧🇲','Brazil':'🇧🇷','Brunei':'🇧🇳','Bulgaria':'🇧🇬','Cambodia':'🇰🇭','Cameroon':'🇨🇲','Canada':'🇨🇦','Cape Verde':'🇨🇻','Cayman Islands':'🇰🇾','Chile':'🇨🇱','China':'🇨🇳','Colombia':'🇨🇴','Comoros':'🇰🇲','Congo (DRC)':'🇨🇩','Congo (Republic)':'🇨🇬','Cook Islands':'🇨🇰','Costa Rica':'🇨🇷','Croatia':'🇭🇷','Cuba':'🇨🇺','Curacao':'🇨🇼','Cyprus':'🇨🇾','Denmark':'🇩🇰','Djibouti':'🇩🇯','Dominica':'🇩🇲','Dominican Republic':'🇩🇴','Ecuador':'🇪🇨','Egypt':'🇪🇬','El Salvador':'🇸🇻','Equatorial Guinea':'🇬🇶','Eritrea':'🇪🇷','Estonia':'🇪🇪','Faroe Islands':'🇫🇴','Fiji':'🇫🇯','Finland':'🇫🇮','France':'🇫🇷','French Polynesia':'🇵🇫','Gabon':'🇬🇦','Gambia':'🇬🇲','Georgia':'🇬🇪','Germany':'🇩🇪','Ghana':'🇬🇭','Gibraltar':'🇬🇮','Greece':'🇬🇷','Greenland':'🇬🇱','Grenada':'🇬🇩','Guam':'🇬🇺','Guatemala':'🇬🇹','Guinea':'🇬🇳','Guinea-Bissau':'🇬🇼','Guyana':'🇬🇾','Haiti':'🇭🇹','Honduras':'🇭🇳','Hong Kong':'🇭🇰','Iceland':'🇮🇸','India':'🇮🇳','Indonesia':'🇮🇩','Iran':'🇮🇷','Iraq':'🇮🇶','Ireland':'🇮🇪','Israel':'🇮🇱','Italy':'🇮🇹','Ivory Coast':'🇨🇮','Jamaica':'🇯🇲','Japan':'🇯🇵','Jordan':'🇯🇴','Kenya':'🇰🇪','Kiribati':'🇰🇮','Kuwait':'🇰🇼','Latvia':'🇱🇻','Lebanon':'🇱🇧','Liberia':'🇱🇷','Libya':'🇱🇾','Lithuania':'🇱🇹','Madagascar':'🇲🇬','Malaysia':'🇲🇾','Maldives':'🇲🇻','Malta':'🇲🇹','Marshall Islands':'🇲🇭','Mauritania':'🇲🇷','Mauritius':'🇲🇺','Mexico':'🇲🇽','Micronesia':'🇫🇲','Monaco':'🇲🇨','Montenegro':'🇲🇪','Morocco':'🇲🇦','Mozambique':'🇲🇿','Myanmar':'🇲🇲','Namibia':'🇳🇦','Nauru':'🇳🇷','Netherlands':'🇳🇱','New Caledonia':'🇳🇨','New Zealand':'🇳🇿','Nicaragua':'🇳🇮','Nigeria':'🇳🇬','North Korea':'🇰🇵','Norway':'🇳🇴','Oman':'🇴🇲','Pakistan':'🇵🇰','Palau':'🇵🇼','Panama':'🇵🇦','Papua New Guinea':'🇵🇬','Paraguay':'🇵🇾','Peru':'🇵🇪','Philippines':'🇵🇭','Poland':'🇵🇱','Portugal':'🇵🇹','Puerto Rico':'🇵🇷','Qatar':'🇶🇦','Romania':'🇷🇴','Russia':'🇷🇺','Saint Kitts and Nevis':'🇰🇳','Saint Lucia':'🇱🇨','Saint Vincent':'🇻🇨','Samoa':'🇼🇸','Sao Tome and Principe':'🇸🇹','Saudi Arabia':'🇸🇦','Senegal':'🇸🇳','Seychelles':'🇸🇨','Sierra Leone':'🇸🇱','Singapore':'🇸🇬','Slovenia':'🇸🇮','Solomon Islands':'🇸🇧','Somalia':'🇸🇴','South Africa':'🇿🇦','South Korea':'🇰🇷','Spain':'🇪🇸','Sri Lanka':'🇱🇰','Sudan':'🇸🇩','Suriname':'🇸🇷','Sweden':'🇸🇪','Syria':'🇸🇾','Taiwan':'🇹🇼','Tanzania':'🇹🇿','Thailand':'🇹🇭','Timor-Leste':'🇹🇱','Togo':'🇹🇬','Tonga':'🇹🇴','Trinidad and Tobago':'🇹🇹','Tunisia':'🇹🇳','Turkey':'🇹🇷','UAE':'🇦🇪','Ukraine':'🇺🇦','United Kingdom':'🇬🇧','United States':'🇺🇸','Uruguay':'🇺🇾','Vanuatu':'🇻🇺','Venezuela':'🇻🇪','Vietnam':'🇻🇳','Virgin Islands (US)':'🇻🇮','Yemen':'🇾🇪',
};

export const PORT_DATA: Record<string, string[]> = {
  'Albania': ['Durrës', 'Vlorë', 'Shëngjin', 'Sarandë'],
  'Algeria': ['Algiers', 'Oran', 'Annaba', 'Skikda', 'Béjaïa', 'Arzew', 'Mostaganem', 'Ghazaouet', 'Djendjene', 'Tenes'],
  'Angola': ['Luanda', 'Lobito', 'Namibe', 'Soyo', 'Cabinda', 'Porto Amboim'],
  'Antigua and Barbuda': ["St. John's"],
  'Argentina': ['Buenos Aires', 'Bahía Blanca', 'Rosario', 'Mar del Plata', 'Quequén', 'San Lorenzo', 'Ushuaia', 'Zarate', 'Campana', 'Puerto Madryn', 'La Plata', 'Puerto Deseado'],
  'Aruba': ['Oranjestad', 'Barcadera', 'San Nicolas'],
  'Australia': ['Port Hedland', 'Fremantle', 'Melbourne', 'Sydney', 'Brisbane', 'Gladstone', 'Darwin', 'Adelaide', 'Townsville', 'Newcastle', 'Geelong', 'Hay Point', 'Dampier', 'Port Kembla', 'Cairns', 'Mackay', 'Port Walcott', 'Esperance', 'Bunbury', 'Albany'],
  'Bahamas': ['Nassau', 'Freeport', 'South Riding Point'],
  'Bahrain': ['Mina Salman', 'Khalifa Bin Salman', 'Sitra'],
  'Bangladesh': ['Chittagong', 'Mongla', 'Payra'],
  'Barbados': ['Bridgetown'],
  'Belgium': ['Antwerp', 'Ghent', 'Zeebrugge', 'Ostend', 'Liège', 'Brussels'],
  'Belize': ['Belize City', 'Big Creek', 'Commerce Bight'],
  'Benin': ['Cotonou'],
  'Bermuda': ['Hamilton', "St. George's", 'Royal Naval Dockyard'],
  'Brazil': ['Santos', 'Rio de Janeiro', 'Paranaguá', 'Itajaí', 'Manaus', 'Fortaleza', 'Recife', 'Salvador', 'Vitória', 'Rio Grande', 'Suape', 'Itaqui', 'Pecém', 'Tubarão', 'Aratu', 'Belém', 'Imbituba', 'Antonina', 'Santarém', 'Maceió'],
  'Brunei': ['Muara', 'Seria'],
  'Bulgaria': ['Varna', 'Burgas', 'Lom', 'Rousse'],
  'Cambodia': ['Sihanoukville', 'Phnom Penh'],
  'Cameroon': ['Douala', 'Kribi', 'Limbe'],
  'Canada': ['Vancouver', 'Prince Rupert', 'Montreal', 'Halifax', 'Saint John NB', 'Thunder Bay', 'Quebec City', 'Hamilton', 'Sept-Îles', 'Port Hawkesbury', 'Sydney NS', 'Churchill', 'Nanaimo', 'Victoria', 'Trois-Rivières', 'Belledune'],
  'Cape Verde': ['Praia', 'Mindelo', 'Palmeira'],
  'Cayman Islands': ['George Town'],
  'Chile': ['Valparaíso', 'San Antonio', 'Antofagasta', 'Iquique', 'Arica', 'Punta Arenas', 'Talcahuano', 'San Vicente', 'Coronel', 'Mejillones', 'Chañaral', 'Lirquén', 'Puerto Montt', 'Coquimbo'],
  'China': ['Shanghai', 'Tianjin', 'Qingdao', 'Guangzhou', 'Ningbo-Zhoushan', 'Shenzhen', 'Dalian', 'Xiamen', 'Nanjing', 'Fuzhou', 'Yantai', 'Lianyungang', 'Rizhao', 'Yingkou', 'Quanzhou', 'Tangshan', 'Beihai', 'Shantou', 'Zhuhai', 'Zhanjiang', 'Hong Kong', 'Haikou', 'Wenzhou', 'Sanya', 'Suzhou', 'Jiangyin', 'Nantong', 'Changshu', 'Taicang', 'Foshan', 'Zhongshan', 'Jiujiang', 'Wuhu', 'Maanshan', 'Yangzhou'],
  'Colombia': ['Cartagena', 'Buenaventura', 'Barranquilla', 'Santa Marta', 'Tumaco', 'Turbo', 'Coveñas', 'Puerto Bolívar'],
  'Comoros': ['Moroni', 'Mutsamudu'],
  'Congo (DRC)': ['Matadi', 'Boma', 'Banana'],
  'Congo (Republic)': ['Pointe-Noire'],
  'Cook Islands': ['Avatiu'],
  'Costa Rica': ['Limón', 'Puntarenas', 'Caldera', 'Moín'],
  'Croatia': ['Rijeka', 'Split', 'Zadar', 'Dubrovnik', 'Ploče', 'Šibenik', 'Pula'],
  'Cuba': ['Havana', 'Mariel', 'Cienfuegos', 'Santiago de Cuba', 'Matanzas', 'Nuevitas'],
  'Curacao': ['Willemstad', 'Bullenbaai'],
  'Cyprus': ['Limassol', 'Famagusta', 'Larnaca', 'Vasilikos'],
  'Denmark': ['Copenhagen', 'Aarhus', 'Esbjerg', 'Fredericia', 'Aalborg', 'Kalundborg', 'Odense', 'Køge', 'Helsingør', 'Skagen'],
  'Djibouti': ['Djibouti', 'Doraleh', 'Tadjourah'],
  'Dominica': ['Roseau', 'Portsmouth'],
  'Dominican Republic': ['Santo Domingo', 'Caucedo', 'Puerto Plata', 'Haina', 'Boca Chica', 'Manzanillo'],
  'Ecuador': ['Guayaquil', 'Manta', 'Esmeraldas', 'Puerto Bolívar', 'Posorja'],
  'Egypt': ['Alexandria', 'Port Said', 'Suez', 'Damietta', 'East Port Said', 'Sokhna', 'Adabiya', 'El Dekheila', 'Safaga', 'Hurghada'],
  'El Salvador': ['Acajutla', 'La Unión'],
  'Equatorial Guinea': ['Malabo', 'Bata', 'Luba'],
  'Eritrea': ['Massawa', 'Assab'],
  'Estonia': ['Tallinn', 'Sillamäe', 'Muuga', 'Paldiski'],
  'Faroe Islands': ['Tórshavn', 'Klaksvík', 'Runavík'],
  'Fiji': ['Suva', 'Lautoka'],
  'Finland': ['Helsinki', 'Kotka', 'Turku', 'Hanko', 'Rauma', 'Kokkola', 'Pori', 'Oulu', 'Hamina', 'Naantali'],
  'France': ['Marseille', 'Le Havre', 'Dunkirk', 'Bordeaux', 'Nantes-Saint-Nazaire', 'Rouen', 'Calais', 'Brest', 'La Rochelle', 'Sète', 'Toulon', 'Cherbourg', 'Boulogne-sur-Mer', 'Bayonne', 'Lorient', 'Fos-sur-Mer'],
  'French Polynesia': ['Papeete'],
  'Gabon': ['Libreville', 'Port-Gentil', 'Owendo'],
  'Gambia': ['Banjul'],
  'Georgia': ['Batumi', 'Poti', 'Kulevi'],
  'Germany': ['Hamburg', 'Bremen', 'Bremerhaven', 'Rostock', 'Lübeck', 'Kiel', 'Emden', 'Wilhelmshaven', 'Cuxhaven', 'Stralsund'],
  'Ghana': ['Tema', 'Takoradi'],
  'Gibraltar': ['Gibraltar'],
  'Greece': ['Piraeus', 'Thessaloniki', 'Volos', 'Patras', 'Heraklion', 'Kavala', 'Elefsina', 'Lavrio', 'Alexandroupoli', 'Igoumenitsa', 'Rhodes', 'Corfu', 'Mykonos', 'Santorini', 'Chania'],
  'Greenland': ['Nuuk', 'Sisimiut', 'Ilulissat'],
  'Grenada': ["St. George's"],
  'Guam': ['Apra Harbor'],
  'Guatemala': ['Puerto Quetzal', 'Puerto Barrios', 'Santo Tomás de Castilla'],
  'Guinea': ['Conakry', 'Kamsar'],
  'Guinea-Bissau': ['Bissau'],
  'Guyana': ['Georgetown', 'New Amsterdam'],
  'Haiti': ['Port-au-Prince', 'Cap-Haïtien'],
  'Honduras': ['Puerto Cortés', 'San Lorenzo', 'Puerto Castilla', 'La Ceiba'],
  'Hong Kong': ['Kwai Tsing', 'Stonecutters', 'Tsing Yi'],
  'Iceland': ['Reykjavik', 'Hafnarfjörður', 'Akureyri', 'Grundartangi', 'Reyðarfjörður'],
  'India': ['Mumbai', 'Chennai', 'Kolkata', 'Kandla', 'Nhava Sheva (JNPT)', 'Visakhapatnam', 'Paradip', 'Cochin', 'Tuticorin', 'Mormugao', 'New Mangalore', 'Ennore', 'Haldia', 'Mundra', 'Pipavav', 'Krishnapatnam', 'Hazira', 'Dahej', 'Karaikal', 'Kakinada', 'Gangavaram'],
  'Indonesia': ['Jakarta / Tanjung Priok', 'Surabaya / Tanjung Perak', 'Belawan (Medan)', 'Makassar', 'Semarang', 'Balikpapan', 'Banjarmasin', 'Pontianak', 'Bitung', 'Dumai', 'Cilacap', 'Palembang', 'Jambi', 'Padang', 'Cilegon', 'Cigading', 'Lhokseumawe', 'Pekanbaru', 'Tarakan', 'Sorong', 'Ambon', 'Kupang', 'Manado', 'Kendari'],
  'Iran': ['Bandar Abbas', 'Imam Khomeini', 'Bushehr', 'Bandar Anzali', 'Chabahar', 'Khorramshahr', 'Bandar Lengeh', 'Assaluyeh'],
  'Iraq': ['Umm Qasr', 'Khor al-Zubair', 'Basra', 'Al Faw'],
  'Ireland': ['Dublin', 'Cork', 'Waterford', 'Galway', 'Limerick', 'Rosslare', 'Foynes'],
  'Israel': ['Haifa', 'Ashdod', 'Eilat'],
  'Italy': ['Genoa', 'Naples', 'Livorno', 'Taranto', 'Venice', 'Trieste', 'Gioia Tauro', 'Civitavecchia', 'Ravenna', 'Ancona', 'La Spezia', 'Cagliari', 'Augusta', 'Palermo', 'Salerno', 'Bari', 'Brindisi', 'Catania', 'Messina', 'Savona', 'Marghera', 'Olbia'],
  'Ivory Coast': ['Abidjan', 'San Pédro'],
  'Jamaica': ['Kingston', 'Montego Bay', 'Port Esquivel'],
  'Japan': ['Yokohama', 'Osaka', 'Nagoya', 'Kobe', 'Tokyo', 'Hakata', 'Chiba', 'Kawasaki', 'Niigata', 'Sakai-Senboku', 'Kita-Kyushu', 'Shimizu', 'Mizushima', 'Tomakomai', 'Sendai', 'Hachinohe', 'Naha', 'Akita', 'Sakata', 'Kashima', 'Wakayama', 'Tokuyama', 'Oita', 'Imari', 'Otaru', 'Hakodate', 'Kanmon'],
  'Jordan': ['Aqaba'],
  'Kenya': ['Mombasa', 'Lamu', 'Kilindini'],
  'Kiribati': ['Tarawa', 'Kiritimati'],
  'Kuwait': ['Kuwait City / Shuwaikh', 'Shuaiba', 'Doha Port', 'Mina Al Ahmadi'],
  'Latvia': ['Riga', 'Ventspils', 'Liepāja'],
  'Lebanon': ['Beirut', 'Tripoli', 'Sidon'],
  'Liberia': ['Monrovia', 'Buchanan', 'Greenville', 'Harper'],
  'Libya': ['Tripoli', 'Benghazi', 'Misrata', 'Tobruk', 'Es Sider', 'Ras Lanuf', 'Marsa El Brega', 'Zueitina'],
  'Lithuania': ['Klaipeda', 'Butinge'],
  'Madagascar': ['Toamasina', 'Mahajanga', 'Toliara', 'Antsiranana'],
  'Malaysia': ['Port Klang', 'Penang', 'Johor', 'Kuching', 'Kota Kinabalu', 'Bintulu', 'Tanjung Pelepas', 'Pasir Gudang', 'Kuantan', 'Labuan', 'Lumut', 'Miri', 'Sandakan'],
  'Maldives': ['Malé'],
  'Malta': ['Valletta / Grand Harbour', 'Marsaxlokk'],
  'Marshall Islands': ['Majuro', 'Ebeye'],
  'Mauritania': ['Nouakchott', 'Nouadhibou'],
  'Mauritius': ['Port Louis'],
  'Mexico': ['Manzanillo', 'Veracruz', 'Altamira', 'Lázaro Cárdenas', 'Ensenada', 'Tampico', 'Coatzacoalcos', 'Tuxpan', 'Mazatlán', 'Topolobampo', 'Progreso', 'Salina Cruz', 'Guaymas', 'Acapulco'],
  'Micronesia': ['Pohnpei', 'Chuuk', 'Yap'],
  'Monaco': ['Monaco'],
  'Montenegro': ['Bar', 'Kotor'],
  'Morocco': ['Casablanca', 'Tanger Med', 'Agadir', 'Safi', 'Nador', 'Jorf Lasfar', 'Mohammedia', 'Laâyoune', 'Dakhla', 'Kenitra'],
  'Mozambique': ['Maputo', 'Beira', 'Nacala', 'Pemba', 'Quelimane'],
  'Myanmar': ['Yangon / Thilawa', 'Kyaukpyu', 'Sittwe', 'Mawlamyine'],
  'Namibia': ['Walvis Bay', 'Lüderitz'],
  'Nauru': ['Aiwo'],
  'Netherlands': ['Rotterdam', 'Amsterdam', 'Vlissingen', 'Moerdijk', 'Terneuzen', 'Den Helder', 'IJmuiden', 'Delfzijl', 'Eemshaven', 'Harlingen', 'Velsen-Noord'],
  'New Caledonia': ['Nouméa'],
  'New Zealand': ['Auckland', 'Tauranga', 'Wellington', 'Lyttelton', 'Port Chalmers', 'Napier', 'Nelson', 'Bluff', 'New Plymouth', 'Timaru'],
  'Nicaragua': ['Corinto', 'Bluefields', 'Puerto Cabezas'],
  'Nigeria': ['Lagos / Apapa', 'Tin Can Island', 'Onne', 'Port Harcourt', 'Calabar', 'Warri', 'Bonny', 'Sapele'],
  'North Korea': ['Nampo', 'Wonsan', 'Hungnam', 'Chongjin', 'Rason'],
  'Norway': ['Oslo', 'Bergen', 'Stavanger', 'Tromsø', 'Trondheim', 'Kristiansand', 'Narvik', 'Mongstad', 'Sture', 'Kårstø', 'Slagentangen', 'Hammerfest', 'Mo i Rana', 'Ålesund'],
  'Oman': ['Muscat / Port Sultan Qaboos', 'Salalah', 'Sohar', 'Duqm', 'Khasab', 'Mina Al Fahal'],
  'Pakistan': ['Karachi', 'Port Qasim', 'Gwadar'],
  'Palau': ['Koror', 'Malakal'],
  'Panama': ['Balboa', 'Manzanillo', 'Colón', 'Cristóbal', 'Vacamonte', 'Charco Azul', 'Almirante', 'Aguadulce'],
  'Papua New Guinea': ['Port Moresby', 'Lae', 'Madang', 'Rabaul', 'Kimbe'],
  'Peru': ['Callao', 'Paita', 'Ilo', 'Matarani', 'Salaverry', 'Chimbote', 'Talara', 'Pisco'],
  'Philippines': ['Manila', 'Cebu', 'Davao', 'General Santos', 'Cagayan de Oro', 'Batangas', 'Subic Bay', 'Iloilo', 'Zamboanga', 'Bacolod', 'Tacloban', 'Dumaguete', 'Surigao', 'Puerto Princesa', 'Tagbilaran', 'Ozamiz', 'Calbayog', 'Legazpi', 'Cagayan', 'Naga'],
  'Poland': ['Gdańsk', 'Gdynia', 'Szczecin', 'Świnoujście', 'Police', 'Kołobrzeg'],
  'Portugal': ['Lisbon', 'Sines', 'Porto / Leixões', 'Setúbal', 'Aveiro', 'Faro', 'Funchal', 'Ponta Delgada'],
  'Puerto Rico': ['San Juan', 'Ponce', 'Mayagüez'],
  'Qatar': ['Doha / Hamad Port', 'Ras Laffan', 'Mesaieed'],
  'Romania': ['Constanța', 'Galați', 'Brăila', 'Tulcea', 'Mangalia', 'Midia'],
  'Russia': ['Novorossiysk', 'St. Petersburg', 'Vladivostok', 'Nakhodka', 'Murmansk', 'Kaliningrad', 'Ust-Luga', 'Primorsk', 'Tuapse', 'Taman', 'Sovetskaya Gavan', 'Vanino', 'Vostochny', 'Magadan', 'Sakhalin (Korsakov)', 'Arkhangelsk', 'Vyborg'],
  'Saint Kitts and Nevis': ['Basseterre', 'Charlestown'],
  'Saint Lucia': ['Castries', 'Vieux Fort'],
  'Saint Vincent': ['Kingstown'],
  'Samoa': ['Apia'],
  'Sao Tome and Principe': ['São Tomé'],
  'Saudi Arabia': ['Jeddah', 'Dammam / King Abdulaziz', 'Yanbu', 'Jubail', 'Jizan', 'Ras Tanura', 'King Fahd Industrial', 'King Abdullah Port', 'Duba'],
  'Senegal': ['Dakar', 'Ziguinchor'],
  'Seychelles': ['Victoria'],
  'Sierra Leone': ['Freetown', 'Pepel'],
  'Singapore': ['Singapore', 'Jurong', 'Tuas', 'Pasir Panjang', 'Sembawang'],
  'Slovenia': ['Koper'],
  'Solomon Islands': ['Honiara', 'Noro'],
  'Somalia': ['Mogadishu', 'Berbera', 'Bosaso', 'Kismayo'],
  'South Africa': ['Durban', 'Cape Town', 'Port Elizabeth', 'Richards Bay', 'East London', 'Saldanha', 'Mossel Bay', 'Ngqura'],
  'South Korea': ['Busan', 'Incheon', 'Ulsan', 'Pohang', 'Gwangyang', 'Pyeongtaek', 'Mokpo', 'Donghae', 'Gunsan', 'Yeosu', 'Masan', 'Jeju'],
  'Spain': ['Barcelona', 'Valencia', 'Bilbao', 'Algeciras', 'Las Palmas', 'Cartagena', 'Huelva', 'Tarragona', 'Vigo', 'A Coruña', 'Gijón', 'Santander', 'Málaga', 'Alicante', 'Castellón', 'Ferrol', 'Avilés', 'Almería', 'Sevilla', 'Pasajes', 'Tenerife', 'Palma de Mallorca'],
  'Sri Lanka': ['Colombo', 'Hambantota', 'Trincomalee', 'Galle'],
  'Sudan': ['Port Sudan', 'Suakin'],
  'Suriname': ['Paramaribo', 'Nieuw Nickerie'],
  'Sweden': ['Gothenburg', 'Stockholm', 'Malmö', 'Gävle', 'Luleå', 'Helsingborg', 'Trelleborg', 'Norrköping', 'Oxelösund', 'Karlshamn'],
  'Syria': ['Latakia', 'Tartus', 'Banias'],
  'Taiwan': ['Kaohsiung', 'Keelung', 'Taichung', 'Hualien', 'Taipei (Taoyuan)', 'Suao', 'Anping', 'Mailiao'],
  'Tanzania': ['Dar es Salaam', 'Tanga', 'Zanzibar', 'Mtwara'],
  'Thailand': ['Bangkok / Laem Chabang', 'Map Ta Phut', 'Songkhla', 'Sattahip', 'Sriracha', 'Phuket', 'Ranong'],
  'Timor-Leste': ['Dili'],
  'Togo': ['Lomé', 'Kpémé'],
  'Tonga': ['Nukuʻalofa'],
  'Trinidad and Tobago': ['Port of Spain', 'Point Lisas', 'Point Fortin', 'Scarborough'],
  'Tunisia': ['Tunis / La Goulette', 'Sousse', 'Sfax', 'Bizerte', 'Gabès', 'Zarzis', 'Skhira'],
  'Turkey': ['Mersin', 'Istanbul', 'Izmir', 'Iskenderun', 'Gemlik', 'Aliaga', 'Derince', 'Samsun', 'Trabzon', 'Antalya', 'Zonguldak', 'Bandırma', 'Mudanya', 'Tekirdağ', 'Ambarli', 'Hopa', 'Rize', 'Ordu', 'Sinop', 'Çanakkale', 'Kocaeli', 'Yarımca', 'Tuzla', 'Karaköy'],
  'UAE': ['Dubai / Jebel Ali', 'Abu Dhabi', 'Sharjah', 'Fujairah', 'Ras Al Khaimah', 'Khalifa Port', 'Hamriyah', 'Ajman', 'Umm Al Quwain', 'Mina Rashid', 'Mina Zayed'],
  'Ukraine': ['Odessa', 'Yuzhne', 'Chornomorsk', 'Mykolaiv', 'Mariupol', 'Berdyansk', 'Reni', 'Izmail'],
  'United Kingdom': ['London', 'Liverpool', 'Southampton', 'Aberdeen', 'Felixstowe', 'Grimsby', 'Tilbury', 'Hull', 'Tees', 'Belfast', 'Milford Haven', 'Immingham', 'Bristol', 'Glasgow', 'Cardiff', 'Portsmouth', 'Plymouth', 'Newport', 'Sullom Voe', 'Sheerness', 'Dover', 'Harwich'],
  'United States': ['New Orleans', 'Houston', 'Los Angeles', 'New York / New Jersey', 'Baltimore', 'Seattle', 'Miami', 'Savannah', 'Charleston', 'Norfolk', 'Long Beach', 'Oakland', 'Tampa', 'Jacksonville', 'Philadelphia', 'Boston', 'Mobile', 'Corpus Christi', 'Beaumont', 'Galveston', 'Port Arthur', 'Tacoma', 'Portland OR', 'San Francisco', 'San Diego', 'Honolulu', 'Anchorage', 'Wilmington NC', 'Port Everglades', 'Pascagoula', 'Lake Charles', 'Freeport TX', 'Texas City', 'Gulfport', 'Brunswick'],
  'Uruguay': ['Montevideo', 'Nueva Palmira', 'Fray Bentos', 'Punta del Este', 'Colonia'],
  'Vanuatu': ['Port Vila', 'Luganville'],
  'Venezuela': ['Maracaibo', 'La Guaira', 'Puerto Cabello', 'Puerto Ordaz', 'El Guamache', 'Guanta', 'Amuay', 'Cardón'],
  'Vietnam': ['Ho Chi Minh City / Cat Lai', 'Hai Phong', 'Da Nang', 'Cai Mep', 'Quy Nhon', 'Vung Tau', 'Nha Trang', 'Phu My', 'Cam Pha', 'Cua Lo', 'Can Tho'],
  'Virgin Islands (US)': ['Charlotte Amalie', 'Christiansted'],
  'Yemen': ['Aden', 'Hodeidah', 'Mukalla', 'Mocha'],
};

export const MARINE_SERVICES = [
  { key: 'engine', label: 'Main & Auxiliary Engine' },
  { key: 'refrigeration', label: 'Refrigeration & HVAC' },
  { key: 'electrical', label: 'Electrical & Automation' },
  { key: 'navigation', label: 'Navigation & Communication' },
  { key: 'diving', label: 'Underwater Diving' },
  { key: 'hull', label: 'Hull, Propeller & Rudder' },
  { key: 'crane', label: 'Crane & Hatch Covers' },
  { key: 'welding', label: 'Welding & Fabrication' },
  { key: 'mooring', label: 'Mooring & Rigging' },
  { key: 'survey', label: 'Classification Survey' },
  { key: 'ndt', label: 'Non-Destructive Testing' },
  { key: 'firefighting', label: 'Fire Fighting & Safety' },
  { key: 'ballast', label: 'Ballast Water Treatment' },
  { key: 'hydraulics', label: 'Hydraulics' },
  { key: 'boiler', label: 'Boiler & Steam Systems' },
  { key: 'painting', label: 'Painting & Blasting' },
  { key: 'sewage', label: 'Sewage & MARPOL' },
  { key: 'liferaft', label: 'Liferaft & LSA Service' },
  { key: 'crew', label: 'Crew Change & Logistics' },
  { key: 'bunker', label: 'Bunker Supply' },
  { key: 'lubricant', label: 'Lubricant Supply' },
  { key: 'freshwater', label: 'Fresh Water Supply' },
  { key: 'garbage', label: 'Garbage & Sludge Disposal' },
  { key: 'tank', label: 'Tank Cleaning' },
  { key: 'slop', label: 'Slop & Bilge Disposal' },
  { key: 'holdcleaning', label: 'Cargo Hold Cleaning' },
  { key: 'lashing', label: 'Lashing & Securing' },
  { key: 'anchor', label: 'Anchor & Chain Service' },
  { key: 'pilotladder', label: 'Pilot Ladder Inspection' },
  { key: 'gasfree', label: 'Gas Free Certification' },
  { key: 'gmdss', label: 'Radio / GMDSS Survey' },
  { key: 'ecdis', label: 'ECDIS Update Service' },
  { key: 'imo', label: 'IMO / Flag Documentation' },
  { key: 'pestcontrol', label: 'Pest Control & Fumigation' },
];

export const CHANDLER_CATEGORIES = [
  { key: 'fresh', label: 'Fresh & Frozen Provisions' },
  { key: 'bonded', label: 'Bonded Stores' },
  { key: 'cabin', label: 'Cabin Stores' },
  { key: 'deck', label: 'Deck Stores' },
  { key: 'engine', label: 'Engine Stores' },
];

export const PROVIDER_TYPES: Record<string, string> = { agent: 'Ship agent', chandler: 'Shipchandler', service: 'Marine services' };

/** A URL-safe slug that keeps accented letters readable (Paranaguá → paranagua, Bandırma → bandirma). */
export function toSlug(text: string): string {
  return String(text)
    .replace(/ı/g, 'i')
    .replace(/İ/g, 'I')
    .replace(/ß/g, 'ss')
    .replace(/[øØ]/g, 'o')
    .replace(/[æÆ]/g, 'ae')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9\s-]/g, ' ')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

/** The old slug style (dropped accented letters): kept so old links can be redirected. */
export function legacySlug(text: string): string {
  return String(text).toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
}

export type PortRef = { name: string; country: string; slug: string; flag: string };

/** Every port we cover, each with a unique slug (a name used in two countries gets the country added). */
export const ALL_PORTS: PortRef[] = (() => {
  const rows: { name: string; country: string }[] = [];
  for (const [country, ports] of Object.entries(PORT_DATA)) for (const name of ports) rows.push({ name, country });
  const count = new Map<string, number>();
  for (const r of rows) count.set(toSlug(r.name), (count.get(toSlug(r.name)) || 0) + 1);
  return rows
    .map((r) => {
      const base = toSlug(r.name);
      return { ...r, slug: (count.get(base) || 0) > 1 ? `${base}-${toSlug(r.country)}` : base, flag: FLAG[r.country] || '' };
    })
    .sort((a, b) => a.name.localeCompare(b.name));
})();

const BY_SLUG = new Map(ALL_PORTS.map((p) => [p.slug, p]));
export const portBySlug = (slug: string) => BY_SLUG.get(slug) || null;

/** A port by its name (and country when known). */
export function findPort(name: string, country?: string): PortRef | null {
  const n = String(name).trim().toLowerCase();
  return ALL_PORTS.find((p) => p.name.toLowerCase() === n && (!country || p.country === country)) || ALL_PORTS.find((p) => p.name.toLowerCase() === n) || null;
}

export const COUNTRY_COUNT = Object.keys(PORT_DATA).length;
export const PORT_COUNT = ALL_PORTS.length;
