// ============================================================
// BLOG POSTS — Modular structure
// ============================================================
import {
  BLOG_POSTS as LEGACY_BLOG_POSTS,
  formatBlogDate as legacyFormatBlogDate,
} from '../blog-posts';
export type { BlogPost, BlogCategory } from '../blog-posts';
import type { BlogPost } from '../blog-posts';
import { shanghai } from './shanghai';
import { hongKong } from './hong-kong';
import { hamburg } from './hamburg';
import { antwerp } from './antwerp';
import { houston } from './houston';
import { busan } from './busan';
import { santos } from './santos';
import { yokohama } from './yokohama';
import { piraeus } from './piraeus';
import { newYorkNewJersey } from './new-york-new-jersey';
import { losAngelesLongBeach } from './los-angeles-long-beach';
import { tanjungPelepas } from './tanjung-pelepas';
import { shenzhen } from './shenzhen';
import { ningboZhoushan } from './ningbo-zhoushan';
import { guangzhou } from './guangzhou';
import { qingdao } from './qingdao';
import { tianjin } from './tianjin';
import { genoa } from './genoa';
import { melbourne } from './melbourne';
import { casablanca } from './casablanca';
import { durban } from './durban';
import { rosario } from './rosario';
import { vancouver } from './vancouver';
import { stPetersburg } from './st-petersburg';
import { mormugao } from './mormugao';
import { shipyardsTop15 } from './shipyards-top-15';
import { singaporeVsHongKongVsShanghai } from './singapore-vs-hong-kong-vs-shanghai';
import { rotterdamVsHamburgVsAntwerp } from './rotterdam-vs-hamburg-vs-antwerp';
import { suezVsPanama } from './suez-vs-panama';
import { howToBecomeShipAgent } from './how-to-become-ship-agent';
import { howToStartShipChandler } from './how-to-start-ship-chandler';
import { marketingForShipAgents } from './marketing-for-ship-agents';
import { bestShipAgencySoftware } from './best-ship-agency-software';
import { howToStartBunkerSupply } from './how-to-start-bunker-supply';
import { howToStartHullCleaning } from './how-to-start-hull-cleaning';
import { howToStartCrewChange } from './how-to-start-crew-change';
import { howToStartShipRepair } from './how-to-start-ship-repair';
import { howToStartMarineSurveying } from './how-to-start-marine-surveying';
import { howToStartMarinePainting } from './how-to-start-marine-painting';
import { howProvidersReachOperators } from './how-providers-reach-operators';
import { losAngelesVsNewYorkVsHouston } from './los-angeles-vs-new-york-vs-houston';
import { maritimeRegulationsChanges2026 } from './maritime-regulations-changes-2026';
import { top20BunkerHubsWorldwide2026 } from './top-20-bunker-hubs-worldwide-2026';
import { euEtsForShipping2026 } from './eu-ets-for-shipping-2026-complete-operator-guide';
import { whatDoesAShipAgentDo } from './what-does-a-ship-agent-do-complete-guide-2026';
import { whatDoesAShipchandlerDo } from './what-does-a-shipchandler-do-complete-guide-2026';
import { fuelEuMaritime2026 } from './fueleu-maritime-2026-compliance-and-pooling-strategy';
import { ukEtsForShipping2026 } from './uk-ets-for-shipping-2026-complete-operator-guide';
import { howToChooseShipAgentBuyerGuide } from './how-to-choose-a-ship-agent-2026-buyer-guide';
import { sydneyPortGuide } from './sydney-port-botany-complete-guide-2026';
import { portKlangGuide } from './port-klang-malaysia-complete-guide-2026';
import { algecirasPortGuide } from './algeciras-port-spain-complete-guide-2026';
import { jnptMumbaiPortGuide } from './jnpt-mumbai-nhava-sheva-complete-guide-2026';
import { felixstowePortGuide } from './felixstowe-port-uk-complete-guide-2026';
import { jebelAliPortGuide } from './jebel-ali-port-dubai-complete-guide-2026';
import { crewChangePortCall } from './crew-change-port-call-operational-checklist-2026';
import { vesselTechnicalServiceVisits } from './vessel-technical-service-visits-port-coordination-guide-2026';
import { singaporeEngineService } from './ship-engine-service-companies-singapore-2026-operator-buyer-guide';
import { singaporeHullCleaning } from './hull-cleaning-services-singapore-2026-operator-buyer-guide';
import { singaporeLiferaftLsaFirefighting } from './liferaft-lsa-firefighting-equipment-servicing-singapore-2026';
import { singaporeDeckCargoHandlingHardware } from './crane-mooring-lashing-anchor-chain-services-singapore-2026';
import { singaporeSafetyComplianceInspections } from './pilot-ladder-gas-free-classification-survey-flag-documentation-singapore-2026';
import { singaporeCargoEnvironmentalCompliance } from './cargo-hold-cleaning-sewage-marpol-slop-bilge-pest-control-singapore-2026';
import { globalShipchandlerIndustryTrends2026 } from './global-shipchandler-industry-2026-provisioning-sourcing-trends';
import { globalShipAgencyIndustryTrends2026 } from './global-ship-agency-industry-2026-appointment-sourcing-trends';
import { globalMarineTechnicalServicesTrends2026 } from './global-marine-technical-services-industry-2026-sourcing-trends';
import { rotterdamBunkerTankCleaningBwts } from './bunker-supply-tank-cleaning-ballast-water-treatment-rotterdam-2026';
import { dubaiCrewChangeLubricantFreshWater } from './crew-change-lubricant-fresh-water-supply-dubai-jebel-ali-2026';
import { houstonNdtBoilerHydraulics } from './non-destructive-testing-boiler-steam-hydraulics-services-houston-2026';
import { piraeusNavigationWeldingGarbage } from './navigation-communication-welding-fabrication-garbage-disposal-piraeus-2026';
import { hongKongBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-hong-kong-2026';
import { shanghaiBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-shanghai-2026';
import { santosBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-santos-2026';
import { yokohamaBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-yokohama-2026';
import { ningboBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-ningbo-2026';
import { bremerhavenBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-bremerhaven-2026';
import { fujairahBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-fujairah-2026';
import { alexandriaBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-alexandria-2026';
import { kuwaitBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-kuwait-2026';
import { mersinBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-mersin-2026';
import { maltaBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-malta-2026';
import { aliagaBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-aliaga-2026';
import { nhavaShevaJnptBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-nhava-sheva-jnpt-2026';
import { tokyoBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-tokyo-2026';
import { southamptonBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-southampton-2026';
import { abuDhabiBunkerCrewChangeTankCleaning } from './bunker-supply-crew-change-tank-cleaning-abu-dhabi-2026';
import { majorWorldPortsTimeZonesScaleFacts } from './major-world-ports-time-zones-scale-operating-facts-2026';
import { majorShippingCanalsChokepoints } from './major-shipping-canals-chokepoints-operator-guide-2026';
import { publicHolidaysBusinessCultureByPortCountry } from './public-holidays-business-culture-major-port-countries-2026';
import { singaporeRegistryOfShipsGuide } from './singapore-registry-of-ships-guide-ship-managers-2026';
import { whySingaporeBusiestPortProviders } from './why-singapore-busiest-port-what-it-means-providers-2026';
import { hongKongEngineRefrigerationElectrical } from './main-auxiliary-engine-refrigeration-electrical-automation-services-hong-kong-2026';
import { tuzlaShipRepair } from './ship-repair-services-tuzla-istanbul-2026-operator-buyer-guide';
import { bosphorusShipAgents } from './ship-agents-istanbul-bosphorus-2026-operator-buyer-guide';
import { istanbulBunkerSuppliers } from './bunker-suppliers-istanbul-2026-operator-buyer-guide';
import { rotterdamShipRepair } from './ship-repair-services-rotterdam-2026-operator-buyer-guide';
import { singaporeShipAgents } from './how-to-find-ship-agents-singapore-2026-operator-buyer-guide';
import { singaporeShipchandlers } from './how-to-find-shipchandlers-singapore-2026-operator-buyer-guide';
import { singaporeBwtsService } from './bwts-service-singapore-2026-operator-buyer-guide';
import { singaporeBoilerService } from './boiler-service-singapore-2026-operator-buyer-guide';
import { singaporeEcdisGmdss } from './ecdis-service-gmdss-radio-survey-singapore-2026-operator-buyer-guide';
import { singaporeMasterGuide } from './marine-service-providers-singapore-2026-complete-guide-operators-providers';
import { singaporeOperationsMegaGuide } from './singapore-maritime-operations-bunker-surveys-spare-parts-crew-change-tank-cleaning-2026-complete-guide';
import { singaporeTechnicalServicesGuide } from './singapore-technical-services-electrical-hydraulics-refrigeration-ndt-2026-complete-guide';
import { shipchandlersIstanbul } from './shipchandlers-istanbul-bosphorus-2026-operator-buyer-guide';
import { howOperatorsSearchForProviders } from './how-vessel-operators-search-for-providers-online-2026';
import { howToStartMarineElectrical } from './how-to-start-marine-electrical-services-business-complete-guide-2026';
import { hiddenCostOfBeingInvisible } from './hidden-cost-invisible-online-ship-agents-chandlers-marine-services-2026';
import { losingBidsToCompetitors } from './why-losing-bids-to-companies-never-heard-of-2026';
import { firstCallToRepeatBusiness } from './first-inquiry-to-repeat-business-ship-agents-chandlers-marine-services-2026';
import { eleventhHourProvisioning } from './eleventh-hour-provisioning-shipchandlers-missing-most-profitable-orders-2026';
import { singaporeScaleOpportunity } from './singapore-130000-vessel-calls-ship-agents-chandlers-marine-services-2026';
import { howOperatorsSearchSingapore } from './how-vessel-operators-search-for-providers-singapore-2026';
import { singaporeShipAgentsCompetition } from './singapore-ship-agent-competition-visibility-wins-2026';
import { singaporeShipyardsMarineService } from './singapore-shipyards-marine-service-provider-demand-2026';
import { singaporeShipchandlersScale } from './singapore-shipchandler-provisioning-demand-visibility-2026';
import { amsterdam } from './amsterdam-port-netherlands-complete-guide-2026';
import { howToVetProviders } from './how-vessel-operators-vet-choose-ship-agents-shipchandlers-marine-services-2026';
import { regulationsProviderOpportunity } from './how-2026-maritime-regulations-create-business-ship-agents-chandlers-marine-services';
import { whatIsMarineServiceProvider } from './what-is-a-marine-service-provider-complete-guide-2026';
import { marineServicesCompleteDirectory } from './marine-service-categories-complete-directory-singapore-worldwide-2026';
import { howToStartUnderwaterDiving } from './how-to-start-underwater-diving-hull-inspection-service-2026';
import { howToStartTankCleaning } from './how-to-start-tank-cleaning-business-complete-guide-2026';
import { howToStartWasteManagement } from './how-to-start-ship-waste-management-business-complete-guide-2026';
import { howToStartFumigation } from './how-to-start-marine-fumigation-business-complete-guide-2026';
import { shipAgentFeesPdaExplained } from './ship-agent-fees-pda-disbursement-account-explained-2026';
import { bundlingMarineServicesOperatorGuide } from './bundling-marine-services-one-provider-vs-specialists-operator-guide-2026';
import { howToStartNdtServices } from './how-to-start-marine-ndt-inspection-business-complete-guide-2026';
import { singaporeBunkerSurveyCompleteGuide } from './bunker-fuel-quantity-survey-singapore-complete-guide-operators-surveyors-2026';
import { singaporeCrewChangeCompleteGuide } from './crew-change-singapore-complete-guide-operators-agents-2026';
import { suezShipAgentsChandlersCompleteGuide } from './suez-canal-ship-agents-shipchandlers-complete-guide-operators-providers-2026';
import { whyProvidersRegisterPortServiceFinder } from './why-ship-agents-shipchandlers-marine-services-register-portservicefinder-2026';
import { professionalLiabilityInsuranceMarineProviders } from './professional-liability-insurance-ship-agents-shipchandlers-marine-services-2026';
import { panamaCanalShipAgentsChandlersCompleteGuide } from './panama-canal-ship-agents-shipchandlers-complete-guide-operators-providers-2026';
import { malaccaStraitShipAgentsChandlersGuide } from './strait-of-malacca-ship-agents-shipchandlers-complete-guide-operators-providers-2026';
import { hormuzStraitShipAgentsChandlersGuide } from './strait-of-hormuz-ship-agents-shipchandlers-complete-guide-operators-providers-2026';
import { gibraltarStraitShipAgentsChandlersGuide } from './strait-of-gibraltar-ship-agents-shipchandlers-complete-guide-operators-providers-2026';
import { danishStraitsShipAgentsChandlersGuide } from './danish-straits-great-belt-oresund-ship-agents-shipchandlers-complete-guide-2026';
import { doverStraitShipAgentsChandlersGuide } from './strait-of-dover-english-channel-ship-agents-shipchandlers-complete-guide-2026';
import { whyShipAgentsRegisterPortServiceFinder } from './why-ship-agents-should-register-portservicefinder-2026';
import { whyShipchandlersRegisterPortServiceFinder } from './why-shipchandlers-should-register-portservicefinder-2026';
import { whyTechnicalServicesRegisterPortServiceFinder } from './why-marine-technical-inspection-services-should-register-portservicefinder-2026';
import { whyNewSmallProvidersRegisterPortServiceFinder } from './why-new-small-marine-service-companies-should-register-portservicefinder-2026';
import { whyMultiPortProvidersRegisterPortServiceFinder } from './why-multi-port-marine-service-companies-should-register-portservicefinder-2026';
import { whyBunkerSuppliersRegisterPortServiceFinder } from './why-bunker-suppliers-should-register-portservicefinder-2026';
import { whyCrewChangeAgentsRegisterPortServiceFinder } from './why-crew-change-agents-should-register-portservicefinder-2026';
import { whyRepairYardsRegisterPortServiceFinder } from './why-ship-repair-yards-should-register-portservicefinder-2026';
import { whyMarineSurveyorsRegisterPortServiceFinder } from './why-marine-surveyors-should-register-portservicefinder-2026';
import { whySingleClientDependentProvidersRegisterPortServiceFinder } from './why-providers-dependent-on-one-client-should-register-portservicefinder-2026';
import { howToStartMaritimeSecurity } from './how-to-start-maritime-security-armed-guard-business-complete-guide-2026';
import { howToStartWeatherRouting } from './how-to-start-weather-routing-services-business-complete-guide-2026';
import { howToStartSalvageTowing } from './how-to-start-marine-salvage-towing-business-complete-guide-2026';
import { howToStartBwtsServices } from './how-to-start-ballast-water-treatment-system-installation-business-complete-guide-2026';
import { howToStartMaritimeCybersecurity } from './how-to-start-maritime-cybersecurity-services-business-complete-guide-2026';
import { howToRespondRfqWinMoreContracts } from './how-to-respond-to-rfq-win-more-maritime-service-contracts-2026';
import { buildingReferralNetworkMarineServices } from './building-referral-network-ship-agents-chandlers-marine-services-2026';
import { usingAisVesselTrackingBusinessDevelopment } from './using-ais-vessel-tracking-data-proactive-business-development-marine-services-2026';
import { multiCurrencyPaymentRiskMarineProviders } from './multi-currency-international-payment-risk-marine-service-providers-2026';
import { buildingCaseStudyPortfolioMarineServices } from './building-case-study-portfolio-win-larger-marine-service-contracts-2026';
import { redFlagsChoosingShipAgent } from './red-flags-choosing-ship-agent-2026';
import { colomboSriLankaGuide } from './colombo-sri-lanka-ship-agents-chandlers-marine-services-2026';
import { howToPriceMarineServices } from './how-to-price-marine-services-competing-with-cheaper-providers-2026';
import { reviewsTrustSignalsMarineServices } from './how-to-collect-reviews-build-trust-ship-agents-chandlers-2026';
import { singaporeDrydockRepairGuide } from './singapore-drydock-ship-repair-welding-painting-2026-complete-guide';
import { singaporeSuppliesWasteGuide } from './singapore-vessel-supplies-waste-management-2026-complete-guide';
import { singaporeSafetySolasGuide } from './singapore-safety-solas-services-2026-complete-guide';
import { singaporeUltimatePillar } from './singapore-maritime-services-2026-ultimate-pillar-guide';
import { singaporePortCallCostGuide } from './singapore-port-call-cost-guide-2026';
import { singaporeEmergencyRepairSalvage } from './singapore-emergency-repair-salvage-2026';
import { seafarerShortage2026OperatorImpact } from './seafarer-shortage-2026-operator-impact';
import { imoNetZeroFramework2026 } from './imo-net-zero-framework-2026-operator-guide';
import { amsterdamProviderOpportunity } from './amsterdam-ship-agents-chandlers-marine-services-specialist-opportunity-2026';
import { rotterdamProviderOpportunity } from './rotterdam-europe-largest-port-ship-agents-chandlers-marine-services-2026';
import { dubaiProviderOpportunity } from './dubai-jebel-ali-ship-agents-chandlers-marine-services-gateway-opportunity-2026';
import { indiaProviderOpportunity } from './india-ports-ship-agents-chandlers-marine-services-opportunity-2026';
import { chinaProviderOpportunity } from './china-ports-ship-agents-chandlers-marine-services-opportunity-2026';
import { indonesiaProviderListicle } from './indonesia-ship-agents-shipchandlers-marine-services-7-reasons-invisible-2026';
import { vietnamProviderOpportunity } from './vietnam-ship-agents-shipchandlers-marine-services-growth-opportunity-2026';
import { turkeyProviderOpportunity } from './turkey-turkish-straits-ship-agents-chandlers-marine-services-2026';
import { lasPalmasProviderOpportunity } from './las-palmas-canary-islands-ship-agents-chandlers-marine-services-bunkering-2026';
import { shipHusbandryGuide } from './what-is-ship-husbandry-complete-guide-2026';
import { marineSurveyorGuide } from './what-is-marine-surveyor-when-you-need-one-2026';
import { aiSearchVisibilityGuide } from './ai-search-visibility-maritime-service-providers-chatgpt-2026';
import { greeceProviderOpportunity } from './greece-piraeus-ship-agents-chandlers-marine-services-shipowning-nation-2026';
import { southKoreaProviderOpportunity } from './south-korea-busan-ship-agents-chandlers-marine-services-shipbuilding-2026';
import { germanyProviderOpportunity } from './germany-bremerhaven-ship-agents-chandlers-marine-services-export-engine-2026';
import { ukProviderOpportunity } from './uk-london-ship-agents-chandlers-marine-services-legal-insurance-hub-2026';
import { philippinesProviderOpportunity } from './philippines-ship-agents-shipchandlers-marine-services-seafarer-nation-2026';
import { southAfricaProviderOpportunity } from './south-africa-durban-cape-town-ship-agents-chandlers-marine-services-cape-route-2026';
import { buenosAiresProviderOpportunity } from './buenos-aires-argentina-ship-agents-chandlers-marine-services-grain-export-2026';
import { gdanskProviderOpportunity } from './gdansk-poland-ship-agents-chandlers-marine-services-baltic-growth-2026';
import { ukMegaGuide } from './uk-britain-ship-agents-shipchandlers-marine-services-complete-guide-2026';
import { usaProviderOpportunity } from './usa-united-states-ports-ship-agents-chandlers-marine-services-2026';
import { canadaProviderOpportunity } from './canada-vancouver-montreal-halifax-ship-agents-chandlers-marine-services-2026';
import { japanProviderOpportunity } from './japan-ship-agents-chandlers-marine-services-precision-reputation-2026';
import { norwayProviderOpportunity } from './norway-ship-agents-chandlers-marine-services-offshore-technology-2026';
import { italyProviderOpportunity } from './italy-genoa-gioia-tauro-ship-agents-chandlers-marine-services-2026';
import { spainProviderOpportunity } from './spain-algeciras-valencia-ship-agents-chandlers-marine-services-2026';
import { moroccoProviderOpportunity } from './morocco-tanger-med-ship-agents-chandlers-marine-services-growth-2026';
import { franceProviderOpportunity } from './france-marseille-le-havre-ship-agents-chandlers-marine-services-2026';
import { saudiProviderOpportunity } from './saudi-arabia-jeddah-ship-agents-chandlers-marine-services-2026';
import { australiaProviderOpportunity } from './australia-ports-ship-agents-chandlers-marine-services-bulk-export-2026';
import { mexicoProviderOpportunity } from './mexico-ports-ship-agents-chandlers-marine-services-nearshoring-2026';
import { nigeriaProviderOpportunity } from './nigeria-lagos-apapa-ship-agents-chandlers-marine-services-2026';
import { qatarProviderOpportunity } from './qatar-ship-agents-chandlers-marine-services-lng-export-2026';
import { chileProviderOpportunity } from './chile-ports-ship-agents-chandlers-marine-services-copper-export-2026';
import { thailandProviderOpportunity } from './thailand-laem-chabang-ship-agents-chandlers-marine-services-automotive-2026';
import { portugalProviderOpportunity } from './portugal-sines-ship-agents-chandlers-marine-services-deepwater-gateway-2026';
import { finlandProviderOpportunity } from './finland-ship-agents-chandlers-marine-services-ice-class-expertise-2026';
import { alternativeFuelBunkeringOpportunity } from './alternative-fuel-bunkering-support-business-opportunity-2026';
import { shipAgencyGlossary2026 } from './ship-agent-shipchandler-marine-services-glossary-2026';
import { shipAgentVsFreightForwarderVsBroker } from './ship-agent-vs-freight-forwarder-vs-ship-broker-difference-explained-2026';
import { vesselPreArrivalInformationChecklist2026 } from './vessel-pre-arrival-information-checklist-ship-agents-2026';
import { laytimeDemurrageAgentDocumentation2026 } from './laytime-demurrage-explained-ship-agent-documentation-role-2026';
import { mlc2006CrewWelfareChandlerRole2026 } from './mlc-2006-crew-welfare-requirements-ship-chandlers-agents-guide-2026';
import { piClubExplainedAgentRole2026 } from './pi-club-protection-indemnity-insurance-explained-ship-agent-role-2026';
import { marineEngineeringRepairServicesBusiness2026 } from './how-to-start-marine-engineering-mechanical-repair-services-business-complete-guide-2026';
import { noticeOfReadinessExplained2026 } from './notice-of-readiness-nor-explained-ship-agent-role-2026';
import { letterOfProtestExplained2026 } from './letter-of-protest-shipping-explained-when-how-2026';
import { marineSurveyorTypesCompared2026 } from './marine-surveyor-types-compared-draft-bunker-condition-cargo-2026';
import { ismCodeExplainedAgentRole2026 } from './ism-code-explained-safety-management-ship-agent-role-2026';
import { stevedoringServicesBusinessGuide2026 } from './how-to-start-stevedoring-cargo-handling-services-business-complete-guide-2026';
import { howToAppointShipAgentChecklist2026 } from './how-to-appoint-a-ship-agent-checklist-2026';
import { proformaVsFinalDisbursementAccount2026 } from './proforma-vs-final-disbursement-account-port-costs-disputes-2026';
import { crewChange2026CostsVisasTimelines } from './crew-change-2026-costs-visas-timelines-agents';
import { shipSupplyDeliveryAnchorage2026 } from './ship-supply-delivery-anchorage-chandlers-guide-2026';
import { howMarineServiceCompaniesWinMorePortCalls2026 } from './how-marine-service-companies-win-more-port-calls-2026';
import { BLOG_REDIRECTS } from './redirects';
export { BLOG_REDIRECTS } from './redirects';
const ALL_POSTS: BlogPost[] = [
  howToAppointShipAgentChecklist2026,
  proformaVsFinalDisbursementAccount2026,
  crewChange2026CostsVisasTimelines,
  shipSupplyDeliveryAnchorage2026,
  howMarineServiceCompaniesWinMorePortCalls2026,
  noticeOfReadinessExplained2026,
  letterOfProtestExplained2026,
  marineSurveyorTypesCompared2026,
  ismCodeExplainedAgentRole2026,
  stevedoringServicesBusinessGuide2026,
  marineEngineeringRepairServicesBusiness2026,
  piClubExplainedAgentRole2026,
  mlc2006CrewWelfareChandlerRole2026,
  laytimeDemurrageAgentDocumentation2026,
  vesselPreArrivalInformationChecklist2026,
  shipAgentVsFreightForwarderVsBroker,
  shipAgencyGlossary2026,
  howToRespondRfqWinMoreContracts,
  alternativeFuelBunkeringOpportunity,
  buildingReferralNetworkMarineServices,
  usingAisVesselTrackingBusinessDevelopment,
  multiCurrencyPaymentRiskMarineProviders,
  buildingCaseStudyPortfolioMarineServices,
  howToStartMaritimeSecurity,
  howToStartWeatherRouting,
  howToStartSalvageTowing,
  howToStartBwtsServices,
  howToStartMaritimeCybersecurity,
  whyBunkerSuppliersRegisterPortServiceFinder,
  whyCrewChangeAgentsRegisterPortServiceFinder,
  whyRepairYardsRegisterPortServiceFinder,
  whyMarineSurveyorsRegisterPortServiceFinder,
  whySingleClientDependentProvidersRegisterPortServiceFinder,
  whyShipAgentsRegisterPortServiceFinder,
  whyShipchandlersRegisterPortServiceFinder,
  whyTechnicalServicesRegisterPortServiceFinder,
  whyNewSmallProvidersRegisterPortServiceFinder,
  whyMultiPortProvidersRegisterPortServiceFinder,
  malaccaStraitShipAgentsChandlersGuide,
  hormuzStraitShipAgentsChandlersGuide,
  gibraltarStraitShipAgentsChandlersGuide,
  danishStraitsShipAgentsChandlersGuide,
  doverStraitShipAgentsChandlersGuide,
  panamaCanalShipAgentsChandlersCompleteGuide,
  professionalLiabilityInsuranceMarineProviders,
  whyProvidersRegisterPortServiceFinder,
  suezShipAgentsChandlersCompleteGuide,
  singaporeCrewChangeCompleteGuide,
  singaporeBunkerSurveyCompleteGuide,
  howToStartNdtServices,
  bundlingMarineServicesOperatorGuide,
  shipAgentFeesPdaExplained,
  howToStartFumigation,
  howToStartWasteManagement,
  howToStartTankCleaning,
  reviewsTrustSignalsMarineServices,
  ukMegaGuide,
  usaProviderOpportunity,
  canadaProviderOpportunity,
  japanProviderOpportunity,
  norwayProviderOpportunity,
  italyProviderOpportunity,
  spainProviderOpportunity,
  moroccoProviderOpportunity,
  franceProviderOpportunity,
  saudiProviderOpportunity,
  australiaProviderOpportunity,
  mexicoProviderOpportunity,
  nigeriaProviderOpportunity,
  qatarProviderOpportunity,
  chileProviderOpportunity,
  thailandProviderOpportunity,
  portugalProviderOpportunity,
  finlandProviderOpportunity,
  southAfricaProviderOpportunity,
  philippinesProviderOpportunity,
  buenosAiresProviderOpportunity,
  gdanskProviderOpportunity,
  amsterdamProviderOpportunity,
  rotterdamProviderOpportunity,
  dubaiProviderOpportunity,
  indiaProviderOpportunity,
  chinaProviderOpportunity,
  indonesiaProviderListicle,
  vietnamProviderOpportunity,
  turkeyProviderOpportunity,
  lasPalmasProviderOpportunity,
  shipHusbandryGuide,
  marineSurveyorGuide,
  aiSearchVisibilityGuide,
  greeceProviderOpportunity,
  southKoreaProviderOpportunity,
  germanyProviderOpportunity,
  ukProviderOpportunity,
  ...LEGACY_BLOG_POSTS,
  imoNetZeroFramework2026,
  seafarerShortage2026OperatorImpact,
  singaporeEmergencyRepairSalvage,
  singaporePortCallCostGuide,
  singaporeUltimatePillar,
  singaporeSafetySolasGuide,
  singaporeSuppliesWasteGuide,
  singaporeDrydockRepairGuide,
  singaporeTechnicalServicesGuide,
  singaporeOperationsMegaGuide,
  singaporeMasterGuide,
  singaporeEcdisGmdss,
  singaporeBoilerService,
  singaporeBwtsService,
  singaporeShipchandlers,
  singaporeShipAgents,
  rotterdamShipRepair,
  istanbulBunkerSuppliers,
  bosphorusShipAgents,
  tuzlaShipRepair,
  singaporeHullCleaning,
  singaporeLiferaftLsaFirefighting,
  singaporeDeckCargoHandlingHardware,
  singaporeSafetyComplianceInspections,
  singaporeCargoEnvironmentalCompliance,
  globalShipchandlerIndustryTrends2026,
  globalShipAgencyIndustryTrends2026,
  globalMarineTechnicalServicesTrends2026,
  rotterdamBunkerTankCleaningBwts,
  dubaiCrewChangeLubricantFreshWater,
  houstonNdtBoilerHydraulics,
  piraeusNavigationWeldingGarbage,
  hongKongBunkerCrewChangeTankCleaning,
  shanghaiBunkerCrewChangeTankCleaning,
  santosBunkerCrewChangeTankCleaning,
  yokohamaBunkerCrewChangeTankCleaning,
  ningboBunkerCrewChangeTankCleaning,
  bremerhavenBunkerCrewChangeTankCleaning,
  fujairahBunkerCrewChangeTankCleaning,
  alexandriaBunkerCrewChangeTankCleaning,
  kuwaitBunkerCrewChangeTankCleaning,
  mersinBunkerCrewChangeTankCleaning,
  maltaBunkerCrewChangeTankCleaning,
  aliagaBunkerCrewChangeTankCleaning,
  nhavaShevaJnptBunkerCrewChangeTankCleaning,
  tokyoBunkerCrewChangeTankCleaning,
  southamptonBunkerCrewChangeTankCleaning,
  abuDhabiBunkerCrewChangeTankCleaning,
  majorWorldPortsTimeZonesScaleFacts,
  majorShippingCanalsChokepoints,
  publicHolidaysBusinessCultureByPortCountry,
  singaporeRegistryOfShipsGuide,
  whySingaporeBusiestPortProviders,
  hongKongEngineRefrigerationElectrical,
  singaporeEngineService,
  vesselTechnicalServiceVisits,
  crewChangePortCall,
  shanghai,
  hongKong,
  hamburg,
  antwerp,
  houston,
  busan,
  santos,
  yokohama,
  piraeus,
  newYorkNewJersey,
  losAngelesLongBeach,
  tanjungPelepas,
  shenzhen,
  ningboZhoushan,
  guangzhou,
  qingdao,
  tianjin,
  genoa,
  melbourne,
  casablanca,
  durban,
  rosario,
  vancouver,
  stPetersburg,
  mormugao,
  shipyardsTop15,
  singaporeVsHongKongVsShanghai,
  rotterdamVsHamburgVsAntwerp,
  suezVsPanama,
  howToBecomeShipAgent,
  howToStartShipChandler,
  marketingForShipAgents,
  bestShipAgencySoftware,
  howToStartBunkerSupply,
  howToStartHullCleaning,
  howToStartCrewChange,
  howToStartShipRepair,
  howToStartMarineSurveying,
  howToStartMarinePainting,
  howProvidersReachOperators,
  losAngelesVsNewYorkVsHouston,
  maritimeRegulationsChanges2026,
  top20BunkerHubsWorldwide2026,
  euEtsForShipping2026,
  whatDoesAShipAgentDo,
  whatDoesAShipchandlerDo,
  fuelEuMaritime2026,
  ukEtsForShipping2026,
  howToChooseShipAgentBuyerGuide,
  sydneyPortGuide,
  portKlangGuide,
  algecirasPortGuide,
  jnptMumbaiPortGuide,
  felixstowePortGuide,
  jebelAliPortGuide,
  shipchandlersIstanbul,
  howOperatorsSearchForProviders,
  howToStartMarineElectrical,
  hiddenCostOfBeingInvisible,
  losingBidsToCompetitors,
  firstCallToRepeatBusiness,
  eleventhHourProvisioning,
  singaporeScaleOpportunity,
  howOperatorsSearchSingapore,
  singaporeShipAgentsCompetition,
  singaporeShipyardsMarineService,
  singaporeShipchandlersScale,
  amsterdam,
  howToVetProviders,
  regulationsProviderOpportunity,
  whatIsMarineServiceProvider,
  marineServicesCompleteDirectory,
  howToStartUnderwaterDiving,
  redFlagsChoosingShipAgent,
  colomboSriLankaGuide,
  howToPriceMarineServices,
];

/** Every published post, de-duplicated by slug, with merged posts (see redirects.ts) left out. */
export const BLOG_POSTS: BlogPost[] = (() => {
  const seen = new Set<string>();
  const out: BlogPost[] = [];
  for (const p of ALL_POSTS) {
    if (seen.has(p.slug) || BLOG_REDIRECTS[p.slug]) continue;
    seen.add(p.slug);
    out.push(p);
  }
  return out;
})();

const BY_SLUG = new Map(BLOG_POSTS.map((p) => [p.slug, p]));

export function getAllBlogSlugs(): string[] {
  return BLOG_POSTS.map((p) => p.slug);
}

export function getBlogPost(slug: string): BlogPost | null {
  return BY_SLUG.get(slug) || null;
}

export function getWordCount(post: BlogPost): number {
  return post.content.split(/\s+/).filter(Boolean).length;
}

/** Minutes to read: the post's own figure, or about 220 words a minute. */
export function getReadingTime(post: BlogPost): number {
  return post.readingTime ?? post.readMinutes ?? Math.max(1, Math.round(getWordCount(post) / 220));
}

/** Last-updated date (ISO), never earlier than the published date. */
export function getUpdatedDate(post: BlogPost): string {
  return post.updatedDate && post.updatedDate > post.publishedDate ? post.updatedDate : post.publishedDate;
}

// ------------------------------------------------------------
// Categories: the raw category values are grouped into a few reader-facing sections.
// ------------------------------------------------------------
export const BLOG_CATEGORY_GROUPS: { key: string; label: string; categories: BlogPost['category'][] }[] = [
  { key: 'port-guides', label: 'Port guides', categories: ['port-guide', 'port-guides', 'comparison'] },
  { key: 'operations', label: 'Operations and how-to', categories: ['how-to', 'tips', 'maritime-fundamentals'] },
  { key: 'regulations', label: 'Regulations', categories: ['regulations', 'regulatory', 'industry-regulations'] },
  { key: 'insights', label: 'Industry insights', categories: ['industry-insights'] },
  { key: 'providers', label: 'For service providers', categories: ['business', 'starting-a-business'] },
];

export function getCategoryGroup(category: BlogPost['category']) {
  return BLOG_CATEGORY_GROUPS.find((g) => g.categories.includes(category)) || BLOG_CATEGORY_GROUPS[3];
}

// ------------------------------------------------------------
// Related posts: same port and category first, then shared keywords, then newest.
// ------------------------------------------------------------
const GENERIC_PORTS = new Set([
  'global', 'for providers', 'for operators', 'operations', 'global canals', 'asia-pacific', 'americas', 'northern europe',
]);
const STOP = new Set([
  'with', 'from', 'that', 'this', 'what', 'your', 'guide', 'complete', '2026', 'ship', 'ships', 'port', 'ports', 'marine',
  'maritime', 'services', 'service', 'vessel', 'operators', 'operator', 'providers', 'provider', 'about', 'they', 'their',
  'how', 'and', 'for', 'the', 'into', 'when', 'where', 'which', 'more', 'than', 'explained', 'everything',
]);

function norm(s?: string) {
  return (s || '').trim().toLowerCase();
}

function tokens(post: BlogPost): Set<string> {
  const text = [post.title, ...(post.keywords || []), ...(post.tags || [])].join(' ').toLowerCase();
  return new Set(text.split(/[^a-z0-9]+/).filter((t) => t.length >= 4 && !STOP.has(t)));
}

export function getRelatedPosts(current: BlogPost | string, limit: number = 4): BlogPost[] {
  const post = typeof current === 'string' ? getBlogPost(current) : current;
  if (!post) return BLOG_POSTS.slice(0, limit);
  const port = norm(post.featuredPort);
  const group = getCategoryGroup(post.category).key;
  const keys = new Set((post.keywords || []).map(norm));
  const toks = tokens(post);

  const scored = BLOG_POSTS.filter((p) => p.slug !== post.slug).map((p) => {
    let score = 0;
    const pPort = norm(p.featuredPort);
    if (port && pPort === port) score += GENERIC_PORTS.has(port) ? 2 : 6;
    if (getCategoryGroup(p.category).key === group) score += 3;
    if (p.category === post.category) score += 1;
    for (const k of p.keywords || []) if (keys.has(norm(k))) score += 2;
    let shared = 0;
    for (const t of tokens(p)) if (toks.has(t)) shared++;
    score += Math.min(shared, 8) * 0.75;
    return { p, score };
  });

  scored.sort((a, b) => b.score - a.score || getUpdatedDate(b.p).localeCompare(getUpdatedDate(a.p)));
  return scored.slice(0, limit).map((s) => s.p);
}

export function formatBlogDate(dateString: string): string {
  return legacyFormatBlogDate(dateString);
}
